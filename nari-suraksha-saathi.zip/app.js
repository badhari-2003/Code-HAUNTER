// Application data
const appData = {
  "ngos": [
    {
      "name": "Women's Rights Foundation",
      "focus": "Domestic Violence",
      "contactPhone": "tel:+91-9876543210",
      "contactEmail": "help@wrf.org",
      "location": "Delhi",
      "whatsappLink": "https://wa.me/919876543210",
      "websiteLink": "https://example-wrf.org"
    },
    {
      "name": "Labor Rights Initiative",
      "focus": "Labor Rights",
      "contactPhone": "tel:+91-8765432109",
      "contactEmail": "support@lri.org",
      "location": "Mumbai",
      "whatsappLink": "https://wa.me/918765432109",
      "websiteLink": "https://example-lri.org"
    },
    {
      "name": "Shakti Support Center",
      "focus": "Sexual Harassment",
      "contactPhone": "tel:+91-7654321098",
      "contactEmail": "help@shakti.org",
      "location": "Bangalore",
      "whatsappLink": "https://wa.me/917654321098",
      "websiteLink": "https://example-shakti.org"
    },
    {
      "name": "Informal Workers Alliance",
      "focus": "Workplace Safety",
      "contactPhone": "tel:+91-6543210987",
      "contactEmail": "contact@iwa.org",
      "location": "Chennai",
      "whatsappLink": "https://wa.me/916543210987",
      "websiteLink": "https://example-iwa.org"
    },
    {
      "name": "Legal Aid Society",
      "focus": "Legal Support",
      "contactPhone": "tel:+91-5432109876",
      "contactEmail": "legal@las.org",
      "location": "Kolkata",
      "whatsappLink": "https://wa.me/915432109876",
      "websiteLink": "https://example-las.org"
    },
    {
      "name": "Women Empowerment Network",
      "focus": "Economic Rights",
      "contactPhone": "tel:+91-4321098765",
      "contactEmail": "info@wen.org",
      "location": "Pune",
      "whatsappLink": "https://wa.me/914321098765",
      "websiteLink": "https://example-wen.org"
    },
    {
      "name": "Safe Workspace Initiative",
      "focus": "Workplace Harassment",
      "contactPhone": "tel:+91-3210987654",
      "contactEmail": "help@swi.org",
      "location": "Hyderabad",
      "whatsappLink": "https://wa.me/913210987654",
      "websiteLink": "https://example-swi.org"
    }
  ],
  "legalInfo": {
    "english": {
      "whatIsHarassment": [
        "Physical harassment includes unwanted touching, hitting, or physical intimidation",
        "Verbal harassment includes abusive language, threats, or demeaning comments about your gender",
        "Sexual harassment includes unwelcome sexual advances, inappropriate comments, or requests for sexual favors",
        "Economic harassment includes withholding wages, unequal pay, or threatening job loss"
      ],
      "yourRights": [
        "You have the right to work in a safe environment free from harassment",
        "The POSH Act (Prevention of Sexual Harassment) protects women at all workplaces",
        "You have the right to file a complaint without fear of retaliation",
        "Your employer must provide a safe working environment",
        "You have the right to fair wages and equal treatment"
      ],
      "howToReport": [
        "Document incidents with dates, times, and witnesses if possible",
        "Report to your supervisor or HR department if available",
        "Contact local NGOs for support and guidance",
        "File complaints with labor authorities when necessary",
        "Seek legal aid for serious cases"
      ]
    },
    "hindi": {
      "whatIsHarassment": [
        "शारीरिक उत्पीड़न में अनचाहा स्पर्श, मारपीट या शारीरिक धमकी शामिल है",
        "मौखिक उत्पीड़न में अपमानजनक भाषा, धमकी या आपके लिंग के बारे में अपमानजनक टिप्पणी शामिल है",
        "यौन उत्पीड़न में अवांछित यौन प्रगति, अनुचित टिप्पणी या यौन उपकार के लिए अनुरोध शामिल है",
        "आर्थिक उत्पीड़न में वेतन रोकना, असमान वेतन या नौकरी खोने की धमकी शामिल है"
      ],
      "yourRights": [
        "आपको उत्पीड़न से मुक्त सुरक्षित वातावरण में काम करने का अधिकार है",
        "पॉश एक्ट (यौन उत्पीड़न की रोकथाम) सभी कार्यस्थलों पर महिलाओं की सुरक्षा करता है",
        "आपको प्रतिशोध के डर के बिना शिकायत दर्ज करने का अधिकार है",
        "आपके नियोक्ता को सुरक्षित कार्य वातावरण प्रदान करना चाहिए",
        "आपको उचित वेतन और समान व्यवहार का अधिकार है"
      ],
      "howToReport": [
        "यदि संभव हो तो तारीख, समय और गवाहों के साथ घटनाओं का दस्तावेजीकरण करें",
        "यदि उपलब्ध हो तो अपने पर्यवेक्षक या एचआर विभाग को रिपोर्ट करें",
        "सहायता और मार्गदर्शन के लिए स्थानीय एनजीओ से संपर्क करें",
        "जरूरत पड़ने पर श्रम अधिकारियों के पास शिकायत दर्ज करें",
        "गंभीर मामलों में कानूनी सहायता लें"
      ]
    }
  },
  "safetyTips": [
    "Always inform a trusted person about where you are working and expected return time",
    "Carry a safety alarm or whistle that you can use in emergency situations",
    "Keep emergency contact numbers easily accessible on your phone",
    "Trust your instincts - if something feels wrong, remove yourself from the situation",
    "Try to work in groups or pairs when possible for added security",
    "Know the contact information of local police station and women's helpline",
    "Keep important documents and some money in a safe place separate from your daily belongings"
  ]
};

// Application state
let currentLanguage = 'english';

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
  initializeNavigation();
  initializeReportForm();
  initializeRightsSection();
  initializeHelpSection();
  initializeSafetyTips();
  setupEventListeners();
  
  // Show home section by default
  showSection('home');
});

// Navigation functionality
function initializeNavigation() {
  // Mobile menu toggle
  const navToggle = document.getElementById('navToggle');
  const navMenu = document.getElementById('navMenu');
  
  if (navToggle && navMenu) {
    navToggle.addEventListener('click', function(e) {
      e.preventDefault();
      navToggle.classList.toggle('active');
      navMenu.classList.toggle('active');
    });
  }

  // Navigation links - handle both nav links and buttons with data-section
  const navigationElements = document.querySelectorAll('[data-section]');
  
  navigationElements.forEach((element) => {
    element.addEventListener('click', function(e) {
      e.preventDefault();
      const targetSection = this.getAttribute('data-section');
      
      if (targetSection) {
        showSection(targetSection);
        
        // Close mobile menu if open
        if (navToggle && navMenu) {
          navToggle.classList.remove('active');
          navMenu.classList.remove('active');
        }
      }
    });
  });

  // Also handle regular nav links with href
  const navLinks = document.querySelectorAll('.nav__link[href]');
  navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const href = this.getAttribute('href');
      if (href && href.startsWith('#')) {
        const sectionId = href.substring(1);
        showSection(sectionId);
        
        // Close mobile menu
        if (navToggle && navMenu) {
          navToggle.classList.remove('active');
          navMenu.classList.remove('active');
        }
      }
    });
  });
}

function showSection(sectionId) {
  // Hide all sections
  const sections = document.querySelectorAll('.section');
  sections.forEach(section => {
    section.classList.remove('active');
  });

  // Show target section
  const targetSection = document.getElementById(sectionId);
  if (targetSection) {
    targetSection.classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // Update navigation active state
  const navLinks = document.querySelectorAll('.nav__link');
  navLinks.forEach(link => {
    link.classList.remove('active');
    const linkSection = link.getAttribute('data-section') || 
                       (link.getAttribute('href') ? link.getAttribute('href').substring(1) : '');
    if (linkSection === sectionId) {
      link.classList.add('active');
    }
  });
}

// Report form functionality
function initializeReportForm() {
  const reportForm = document.getElementById('reportForm');
  
  if (reportForm) {
    reportForm.addEventListener('submit', function(e) {
      e.preventDefault();
      
      if (validateReportForm()) {
        submitReport();
      }
    });
  }
}

function validateReportForm() {
  let isValid = true;
  const fields = [
    { id: 'incidentType', message: 'Please select an incident type' },
    { id: 'description', message: 'Please provide a brief description' },
    { id: 'location', message: 'Please specify the location' },
    { id: 'incidentDate', message: 'Please select the date of incident' }
  ];

  // Clear all previous errors
  clearFormErrors();

  // Validate required fields
  fields.forEach(field => {
    const element = document.getElementById(field.id);
    if (element) {
      const value = element.value.trim();
      
      if (!value) {
        showFieldError(field.id, field.message);
        isValid = false;
      }
    }
  });

  // Validate anonymous radio buttons
  const anonymousRadios = document.querySelectorAll('input[name="anonymous"]');
  const anonymousChecked = Array.from(anonymousRadios).some(radio => radio.checked);
  
  if (!anonymousChecked) {
    showFieldError('anonymous', 'Please select whether to report anonymously');
    isValid = false;
  }

  // Validate date (not in future)
  const incidentDateElement = document.getElementById('incidentDate');
  if (incidentDateElement && incidentDateElement.value) {
    const selectedDate = new Date(incidentDateElement.value);
    const today = new Date();
    today.setHours(23, 59, 59, 999);
    
    if (selectedDate > today) {
      showFieldError('incidentDate', 'Incident date cannot be in the future');
      isValid = false;
    }
  }

  return isValid;
}

function clearFormErrors() {
  const errorElements = document.querySelectorAll('.form-error');
  errorElements.forEach(error => {
    error.classList.remove('show');
    error.textContent = '';
  });
}

function showFieldError(fieldId, message) {
  const errorElement = document.getElementById(`${fieldId}-error`);
  if (errorElement) {
    errorElement.textContent = message;
    errorElement.classList.add('show');
  }
}

function submitReport() {
  // Collect form data
  const formData = {
    incidentType: document.getElementById('incidentType').value,
    description: document.getElementById('description').value,
    location: document.getElementById('location').value,
    incidentDate: document.getElementById('incidentDate').value,
    anonymous: document.querySelector('input[name="anonymous"]:checked').value
  };

  // Display success message with form data
  displayReportSummary(formData);
  
  // Hide form and show success message
  const reportForm = document.getElementById('reportForm');
  const reportSuccess = document.getElementById('reportSuccess');
  
  if (reportForm && reportSuccess) {
    reportForm.style.display = 'none';
    reportSuccess.classList.remove('hidden');
  }
}

function displayReportSummary(data) {
  const incidentTypeLabels = {
    'physical': 'Physical Harassment',
    'verbal': 'Verbal Harassment',
    'sexual': 'Sexual Harassment',
    'economic': 'Economic Harassment',
    'other': 'Other'
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const reportSummary = document.getElementById('reportSummary');
  if (reportSummary) {
    reportSummary.innerHTML = `
      <h4>Report Summary (Prototype Data)</h4>
      <p><strong>Type:</strong> <span>${incidentTypeLabels[data.incidentType] || data.incidentType}</span></p>
      <p><strong>Location:</strong> <span>${data.location}</span></p>
      <p><strong>Date:</strong> <span>${formatDate(data.incidentDate)}</span></p>
      <p><strong>Anonymous:</strong> <span>${data.anonymous === 'yes' ? 'Yes' : 'No'}</span></p>
      <p><strong>Description:</strong> <span>${data.description}</span></p>
    `;
  }
}

function resetReportForm() {
  const reportForm = document.getElementById('reportForm');
  const reportSuccess = document.getElementById('reportSuccess');
  
  if (reportForm && reportSuccess) {
    reportForm.reset();
    clearFormErrors();
    reportForm.style.display = 'block';
    reportSuccess.classList.add('hidden');
  }
}

// Make resetReportForm globally available
window.resetReportForm = resetReportForm;

// Rights section functionality
function initializeRightsSection() {
  const langButtons = document.querySelectorAll('.lang-btn');
  
  langButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      const selectedLang = this.getAttribute('data-lang');
      switchLanguage(selectedLang);
      
      // Update button states
      langButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
    });
  });

  // Load initial content
  loadRightsContent();
}

function switchLanguage(language) {
  currentLanguage = language;
  loadRightsContent();
}

function loadRightsContent() {
  const content = appData.legalInfo[currentLanguage];
  
  // Update harassment list
  const harassmentList = document.getElementById('harassment-list');
  if (harassmentList) {
    harassmentList.innerHTML = content.whatIsHarassment
      .map(item => `<li>${item}</li>`)
      .join('');
  }

  // Update rights list
  const rightsList = document.getElementById('rights-list');
  if (rightsList) {
    rightsList.innerHTML = content.yourRights
      .map(item => `<li>${item}</li>`)
      .join('');
  }

  // Update report list
  const reportList = document.getElementById('report-list');
  if (reportList) {
    reportList.innerHTML = content.howToReport
      .map(item => `<li>${item}</li>`)
      .join('');
  }
}

// Help section functionality
function initializeHelpSection() {
  const focusFilter = document.getElementById('focusFilter');
  const locationFilter = document.getElementById('locationFilter');
  
  if (focusFilter && locationFilter) {
    focusFilter.addEventListener('change', filterNGOs);
    locationFilter.addEventListener('change', filterNGOs);
  }
  
  // Load initial NGO grid
  displayNGOs(appData.ngos);
}

function filterNGOs() {
  const focusFilter = document.getElementById('focusFilter');
  const locationFilter = document.getElementById('locationFilter');
  
  const focusValue = focusFilter ? focusFilter.value : '';
  const locationValue = locationFilter ? locationFilter.value : '';
  
  const filteredNGOs = appData.ngos.filter(ngo => {
    const matchesFocus = !focusValue || ngo.focus === focusValue;
    const matchesLocation = !locationValue || ngo.location === locationValue;
    return matchesFocus && matchesLocation;
  });
  
  displayNGOs(filteredNGOs);
}

function displayNGOs(ngos) {
  const ngoGrid = document.getElementById('ngoGrid');
  
  if (!ngoGrid) return;
  
  if (ngos.length === 0) {
    ngoGrid.innerHTML = `
      <div class="card" style="grid-column: 1 / -1; text-align: center; padding: 2rem;">
        <p>No organizations found matching your criteria. Please try different filters.</p>
      </div>
    `;
    return;
  }
  
  ngoGrid.innerHTML = ngos.map(ngo => `
    <div class="ngo-card">
      <div class="ngo-card__header">
        <h3 class="ngo-card__title">${ngo.name}</h3>
        <p class="ngo-card__focus">${ngo.focus}</p>
      </div>
      <div class="ngo-card__body">
        <p class="ngo-card__location">📍 ${ngo.location}</p>
        <div class="ngo-card__actions">
          <a href="${ngo.contactPhone}" class="btn btn--call btn--sm">Call Now</a>
          <a href="${ngo.whatsappLink}" target="_blank" class="btn btn--whatsapp btn--sm">WhatsApp</a>
        </div>
      </div>
    </div>
  `).join('');
}

// Safety tips functionality
function initializeSafetyTips() {
  const tipsGrid = document.getElementById('tipsGrid');
  const tipIcons = ['🛡️', '📞', '👥', '🚨', '💡', '📋', '🔐'];
  
  if (tipsGrid) {
    tipsGrid.innerHTML = appData.safetyTips.map((tip, index) => `
      <div class="tip-card">
        <div class="tip-card__icon">${tipIcons[index % tipIcons.length]}</div>
        <div class="tip-card__content">
          <h3 class="tip-card__title">Safety Tip ${index + 1}</h3>
          <p class="tip-card__description">${tip}</p>
        </div>
      </div>
    `).join('');
  }
}

// Additional event listeners
function setupEventListeners() {
  // Close mobile menu when clicking outside
  document.addEventListener('click', function(e) {
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    
    if (navToggle && navMenu) {
      if (!navToggle.contains(e.target) && !navMenu.contains(e.target)) {
        navToggle.classList.remove('active');
        navMenu.classList.remove('active');
      }
    }
  });

  // Handle form input changes to clear errors
  const formInputs = document.querySelectorAll('#reportForm input, #reportForm select, #reportForm textarea');
  formInputs.forEach(input => {
    input.addEventListener('change', function() {
      const errorElement = document.getElementById(`${this.id}-error`);
      if (errorElement && errorElement.classList.contains('show')) {
        errorElement.classList.remove('show');
        errorElement.textContent = '';
      }
    });
  });

  // Handle radio button changes
  const radioInputs = document.querySelectorAll('input[name="anonymous"]');
  radioInputs.forEach(input => {
    input.addEventListener('change', function() {
      const errorElement = document.getElementById('anonymous-error');
      if (errorElement && errorElement.classList.contains('show')) {
        errorElement.classList.remove('show');
        errorElement.textContent = '';
      }
    });
  });
}